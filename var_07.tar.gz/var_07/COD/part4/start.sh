./PL_I < ./examppl.pli
